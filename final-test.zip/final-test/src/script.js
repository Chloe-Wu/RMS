////alertBtn
var alertBtn = 0
var alertBtn2 = 0
var alertBtn3 = 0
var alertBtn4 = 0

function alertOneFunction(){
  alert("message sent!");
  alertBtn = 1
    var dbRef = firebase.database().ref('/');
 dbRef.update({"alert":alertBtn});
}

function alertTwoFunction(){
  alert("message sent!");
  alertBtn2 = 1
    var dbRef = firebase.database().ref('/');
 dbRef.update({"alert2":alertBtn2});
}
function alertThreeFunction(){
  alert("message sent!");
  alertBtn3 = 1
    var dbRef = firebase.database().ref('/');
 dbRef.update({"alert3":alertBtn3});
}
function alertFourFunction(){
  alert("message sent!");
  alertBtn4 = 1
    var dbRef = firebase.database().ref('/');
 dbRef.update({"alert4":alertBtn4});
}
//////////

var isLoggedIn = false;
var config = {
    // apiKey: "AIzaSyBoDopRWPCT-h2CpbTQCmwUXTiG9zd_YRU",
    // authDomain: "robot-app-50a41.firebaseapp.com",
    // databaseURL: "https://robot-app-50a41-default-rtdb.firebaseio.com",
    // projectId: "robot-app-50a41",
    // storageBucket: "robot-app-50a41.appspot.com",
    // messagingSenderId: "1024534536678",
    // appId: "1:1024534536678:web:cefe605646ce8b3f9eb627",
    // measurementId: "${config.measurementId}"
  
    //Yiwei's database
    apiKey: "AIzaSyC5LoSfnA8HCtqpzhv94Wl9P6vOC5GYdoM",
    authDomain: "arduinonanoiot.firebaseapp.com",
    databaseURL: "https://arduinonanoiot-default-rtdb.firebaseio.com",
    projectId: "arduinonanoiot",
    storageBucket: "arduinonanoiot.appspot.com",
    messagingSenderId: "1007020323088",
    appId: "1:1007020323088:web:79d7e47e59007bcf497595",
    measurementId: "G-DQBK96Y833"
  };

/*This function is called when the page is loaded*/
function handleLoadEvent() {
  firebase.initializeApp(config);
  firebase.auth().signInAnonymously().catch(handleLoginError);
  firebase.auth().onAuthStateChanged(handleAuthSuccess);
  var dbRef = firebase.database().ref('/');
  dbRef.on("value", showData);
}

function handleLoginError(error) {
  console.log("error.code:" + error.code)
  console.log("error.message:" + error.message)
}

function handleAuthSuccess(user) {
  if (user) {
    // User is signed in.
    var isAnonymous = user.isAnonymous;
    var uid = user.uid;
    isLoggedIn = true;
    // var button = document.getElementById("speakButton");
    // button.disabled = false;
    console.log("Now logged in as " + uid);
  }
};




/*This function handles a value change event triggered from the database*/
function showData(snapshot) {

  /* Get the data value into a Javascript object*/
  var sensorReadings = snapshot.val();
  
  // document.getElementById("textInput").value = sensorReadings.say;

  console.log(sensorReadings.detection[0]);
  
  // var detectXY = sensorReadings.detection;
  // var detectX = detectXY[0].x;
  // var detectY = detectXY[0].y;
  var emotion = sensorReadings.detection[0].emotion;
  var warning = sensorReadings.absent.warn;
  ///////
  
  var emotion2 = sensorReadings.detection2[0].emotion;
  var emotion3 = sensorReadings.detection3[0].emotion;
  var emotion4 = sensorReadings.detection4[0].emotion;
  
  var warning2 = sensorReadings.absent.warn2;
  var warning3 = sensorReadings.absent.warn3;
  var warning4 = sensorReadings.absent.warn4;
  
  var fearNum = 0
  var angryNum = 0
  var happyNum = 0
  var sadNum = 0
  var surprNum = 0
  var disgustNum = 0
  var neutralNum = 0
  var absentNum = 0
  var alertBtn = 0
  
  // document.getElementById("textInputMood").value = 'User emotion detected! '+emotion;
  
 //////first 
  var emoji = document.querySelector("#emoji")
  console.log("hh"+warning)
if(warning == "I cannot see you, please get back!"){
    emoji.innerText = String.fromCodePoint(0x2754)
          absentNum =absentNum + 1 
}
else if(emotion =="happy"){
  emoji.innerText = String.fromCodePoint(0x1F600)
  happyNum =happyNum + 1 
}
else if(emotion =="neutral"){
  emoji.innerText = String.fromCodePoint(0x1F610)
  neutralNum = neutralNum + 1
}
else if(emotion =="sad"){
  emoji.innerText = String.fromCodePoint(0x1F625)
  sadNum =sadNum + 1
}
else if(emotion =="angry"){
  emoji.innerText = String.fromCodePoint(0x1F621)
  angryNum = angryNum + 1
}
else if(emotion =="surprise"){
  emoji.innerText = String.fromCodePoint(0x1F62E)
  surprNum =surprNum + 1
}
else if(emotion =="fear"){
  emoji.innerText = String.fromCodePoint(0x1F628)
  fearNum = fearNum + 1
}
else if(emotion =="disgust"){
  emoji.innerText = String.fromCodePoint(0x1F61F)
  disgustNum = disgustNum + 1
}
  ////second
  
var emoji2 = document.querySelector("#emoji2")

if(warning2 == "I cannot see you, please get back!"){
    emoji2.innerText = String.fromCodePoint(0x2754)
          absentNum =absentNum + 1 
}
else if(emotion2 =="happy"){
  emoji2.innerText = String.fromCodePoint(0x1F600)
  happyNum =happyNum + 1 
}
else if(emotion2 =="neutral"){
  emoji2.innerText = String.fromCodePoint(0x1F610)
  neutralNum = neutralNum + 1
}
else if(emotion2 =="sad"){
  emoji2.innerText = String.fromCodePoint(0x1F625)
  sadNum =sadNum + 1
}
else if(emotion2 =="angry"){
  emoji2.innerText = String.fromCodePoint(0x1F621)
  angryNum = angryNum + 1
}
else if(emotion2 =="surprise"){
  emoji2.innerText = String.fromCodePoint(0x1F62E)
  surprNum =surprNum + 1
}
else if(emotion2 =="fear"){
  emoji2.innerText = String.fromCodePoint(0x1F628)
  fearNum = fearNum + 1
}
else if(emotion2 =="disgust"){
  emoji2.innerText = String.fromCodePoint(0x1F61F)
  disgustNum = disgustNum + 1
}
  //////
var emoji3 = document.querySelector("#emoji3")

if(warning3 == "I cannot see you, please get back!"){
    emoji3.innerText = String.fromCodePoint(0x2754)
          absentNum =absentNum + 1 
}
else if(emotion3 =="happy"){
  emoji3.innerText = String.fromCodePoint(0x1F600)
  happyNum =happyNum + 1 
}
else if(emotion3 =="neutral"){
  emoji3.innerText = String.fromCodePoint(0x1F610)
  neutralNum = neutralNum + 1
}
else if(emotion3 =="sad"){
  emoji3.innerText = String.fromCodePoint(0x1F625)
  sadNum =sadNum + 1
}
else if(emotion3 =="angry"){
  emoji3.innerText = String.fromCodePoint(0x1F621)
  angryNum = angryNum + 1
}
else if(emotion3 =="surprise"){
  emoji3.innerText = String.fromCodePoint(0x1F62E)
  surprNum =surprNum + 1
}
else if(emotion3 =="fear"){
  emoji.innerText = String.fromCodePoint(0x1F628)
  fearNum = fearNum + 1
}
else if(emotion3 =="disgust"){
  emoji3.innerText = String.fromCodePoint(0x1F61F)
  disgustNum = disgustNum + 1
}
  //////
    var emoji4= document.querySelector("#emoji4")
    
    if(warning4 == "I cannot see you, please get back!"){
    emoji4.innerText = String.fromCodePoint(0x2754)
        absentNum =absentNum + 1 
}
else if(emotion4 =="happy"){
  emoji4.innerText = String.fromCodePoint(0x1F600)
  happyNum =happyNum + 1 
}
else if(emotion4 =="neutral"){
  emoji4.innerText = String.fromCodePoint(0x1F610)
  neutralNum = neutralNum + 1
}
else if(emotion4 =="sad"){
  emoji4.innerText = String.fromCodePoint(0x1F625)
  sadNum =sadNum + 1
}
else if(emotion4 =="angry"){
  emoji4.innerText = String.fromCodePoint(0x1F621)
  angryNum = angryNum + 1
}
else if(emotion4 =="surprise"){
  emoji4.innerText = String.fromCodePoint(0x1F62E)
  surprNum =surprNum + 1
}
else if(emotion4 =="fear"){
  emoji4.innerText = String.fromCodePoint(0x1F628)
  fearNum = fearNum + 1
}
else if(emotion4 =="disgust"){
  emoji4.innerText = String.fromCodePoint(0x1F61F)
  disgustNum = disgustNum + 1
}
 ///////////
    const labels = [
    'Fear',
    'Happy',
    'Sad',
    'Surprise',
    'Angry',
    'Neutral',
    'Disgust',
    'Absent',
  ];
  const data = {
    labels: labels,
    datasets: [{
      label: 'My First dataset',
      backgroundColor: ['red','blue','green','purple','orange','pink','brown','gray'],
      borderColor: ['red','blue','green','purple','orange','pink','brown','gray'],
      color:'white',
      data: [fearNum,happyNum,sadNum,surprNum,angryNum,neutralNum,disgustNum,absentNum],
    }]
  };

  const config = {
    type: 'pie',
    data: data,
    options: {
      color:'white'
    }
  };
    const myChart = new Chart(
    document.getElementById('myChart'),
    config
  );
  ////////////
  
  
//   if(emotion == actions[i] && skip == false){
//     speak("How do your feel?", "en-US");
//     document.getElementById("speech").innerHTML = "Your emotion: " + actions[i+1];
//     console.log(i);
//     i += 1;
//     console.log('here is the motion loop!')
//   }
  
//   skip = false;
//   console.log("face detect "+skip)

  
};


// function speakFire() {
//   const textInput = document.getElementById("textInput");
//   const text = textInput.value;
//   speak(text, 'en-US');
// }


// function speakMood() {
//   const textInput = document.getElementById("textInputMood");
//   const text = textInput.value;
//   speak(text, 'en-US');
// }

//camera code



//original code
// var canvas1 = document.getElementById("myCanvas");
// var ctx1 = canvas1.getContext("2d");
// var eyeWidth = 50;
// var pupilWidth = 20;

// draw2 = function(detectX, detectY){
//   ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
//   let mouseX = detectX*1.5;
//   let mouseY = detectY*1.5;
//   var distanceFromCenterX = 100;
//   var eyeCenterY = 150;
//   var noseCenterY = 190;
//   var eyeCenterX1 = canvas1.width/2 + distanceFromCenterX;
//   var eyeCenterX2 = canvas1.width/2 - distanceFromCenterX;
  
  
//   drawEyeback(250-distanceFromCenterX, eyeCenterY);
//   drawEyeback(250+distanceFromCenterX, eyeCenterY);
//   drawEyepupil(eyeCenterX1+(mouseX-eyeCenterX1)/canvas1.width*eyeWidth, eyeCenterY+(mouseY-eyeCenterY)/canvas1.height*eyeWidth-eyeWidth/2);
//   drawEyepupil(eyeCenterX2+(mouseX-eyeCenterX2)/canvas1.width*eyeWidth, eyeCenterY+(mouseY-eyeCenterY)/canvas1.height*eyeWidth-eyeWidth/2);
//   drawNose(250, noseCenterY);  
//   console.log("I can draw face");
// }

// function drawEyepupil(eyeCenterX, eyeCenterY)
// { var pupil;
//   ctx1.fillStyle="white";
//   pupil = ctx1.fillRect(eyeCenterX-pupilWidth/2, eyeCenterY+pupilWidth/2, pupilWidth, pupilWidth);
// }

// function drawEyeback(eyeCenterX, eyeCenterY)
// {
//   var eyeball;
//   ctx1.fillStyle="black";
//   eyeball = ctx1.arc(eyeCenterX, eyeCenterY, eyeWidth, 0 , 2 * Math.PI);
//   ctx1.fill(eyeball);
// }

// function drawNose(noseCenterX, noseCenterY){
//   // var c = document.getElementById("myCanvas");
//   // var ctx = c.getContext("2d");
//   var noseWidth = 20
//   ctx1.fillStyle = "#FF0000";
//   ctx1.fillRect(noseCenterX-noseWidth/2, noseCenterY, noseWidth, 30);
// }





// var grammar =
//   "#JSGF V1.0; grammar emar; public <greeting> = hello | hi; <person> = Wesley | Beck;";
// var recognition = new window.webkitSpeechRecognition();
// var speechRecognitionList = new window.webkitSpeechGrammarList();
// speechRecognitionList.addFromString(grammar, 1);
// recognition.grammars = speechRecognitionList;
// recognition.continuous = true;
// recognition.lang = "en-US";
// recognition.interimResults = false;
// recognition.maxAlternatives = 1;


// var i =0
// var skip = false;

// function startRecognition() {
//   recognition.start();
// };


// recognition.onresult = processSpeech;

// var actions = ['happy','neutral','happy', 'neutral','happy', 'fear','have a rest','happy']


// function processSpeech(event) {
//   var inputSpeech = event.results[0][0].transcript;
//   var textDiv = document.getElementById("answer");
//   textDiv.innerHTML = "you said: " + inputSpeech
//   // speak(inputSpeech, "en-US");
//   recognition.stop();
//   if(inputSpeech == 'I got it'){
//     speak("alright, let's move to next action", "en-US");
//     document.getElementById("speech").innerHTML = "please do the following: " + actions[i+1];
//     skip = true;
//     console.log(skip);
//     if(i==6){
//       i=0
//       speak("well done, let us do another group", "en-US");
//     }else{
//       i += 1
//     }
//   }
  
// }

// recognition.onend = recognitionEnded;

// function recognitionEnded() {
//   console.log("onend happened");
//   recognition.stop();
//   // if document.getElementById("answer").innerHTML!= "...":
// }


// function speak(text, lang) {
//   /*Check that your browser supports text to speech*/
//   if ('speechSynthesis' in window) {
//     const msg = new SpeechSynthesisUtterance();
//     const voices = window.speechSynthesis.getVoices();
//     if (voices.length > 0) {
//       console.log("Your browser supports " + voices.length + " voices");
//       console.log(voices);
//       msg.voice = voices.filter(function(voice) { return voice.lang == lang; })[1];
//     }
//     msg.voiceURI = 'native';
//     msg.volume = 0.8; // 0 to 1
//     msg.rate = 0.6; // 0.1 to 10
//     msg.pitch = 0.6; //0 to 2
//     msg.text = text;
//     msg.lang = lang;
//     msg.onend = function(e) {
//       console.log('Finished in ' + e.elapsedTime + ' milliseconds.');
//     };
//     speechSynthesis.speak(msg);
//   }
// }





