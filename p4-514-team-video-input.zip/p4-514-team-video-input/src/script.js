
/* This function checks and sets up the camera */
function startVideo() {
  if (navigator.mediaDevices && 
      navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({video: true})
      .then(handleUserMediaSuccess)
      .catch(handleUserMediaError);
  }
}

function handleUserMediaError(error){
  console.log(error);
}

function handleUserMediaSuccess(stream){
  var video = document.getElementById("myVideo");
  video.srcObject = stream;
  // video.play();
  console.log("success");
  window.setInterval(captureImageFromVideo, 200);
}

// The variable that holds the detected face information, which will be updated through Firebase callbacks
var detection = null;

function captureImageFromVideo() {
  const canvas = document.getElementById("mainCanvas");
  const context = canvas.getContext("2d");
  
  const video = document.getElementById("myVideo");
  canvas.setAttribute("width", video.width);
  canvas.setAttribute("height", video.height);  
  // Draw video image onto Canvas
  context.drawImage(video, 0, 0, video.width, video.height);

  sendSnapshot();
  
  //var dataObj = context.getImageData(0, 0, canvas.width, canvas.height);

  // If a face detection has been received from the database, draw a rectangle around it on Canvas
  if (detection) {
    const face = detection[0];
    context.beginPath();
    context.moveTo(face.x, face.y);
    context.lineTo(face.x + face.w, face.y);
    context.lineTo(face.x + face.w, face.y + face.h);
    context.lineTo(face.x, face.y + face.h);
    context.lineTo(face.x, face.y);
    context.lineWidth = 5;
    context.strokeStyle = "#0F0";
    context.fillStyle = "#0F0";
    context.stroke();
  }
}
  
function sendSnapshot() {
  const canvas = document.getElementById("mainCanvas");
  // Convert the image into a a URL string with built0-in canvas function 
  const data = canvas.toDataURL();
  
  const commaIndex = data.indexOf(",");
  
  const imgString = data.substring(commaIndex+1,data.length);
  storeImage(imgString);
}

// Initialize Firebase
var config = {
    // apiKey: "AIzaSyBoDopRWPCT-h2CpbTQCmwUXTiG9zd_YRU",
    // authDomain: "robot-app-50a41.firebaseapp.com",
    // databaseURL: "https://robot-app-50a41-default-rtdb.firebaseio.com",
    // projectId: "robot-app-50a41",
    // storageBucket: "robot-app-50a41.appspot.com",
    // messagingSenderId: "1024534536678",
    // appId: "1:1024534536678:web:cefe605646ce8b3f9eb627",
    // measurementId: "${config.measurementId}"
  
    //Yiwei's database
    apiKey: "AIzaSyC5LoSfnA8HCtqpzhv94Wl9P6vOC5GYdoM",
    authDomain: "arduinonanoiot.firebaseapp.com",
    databaseURL: "https://arduinonanoiot-default-rtdb.firebaseio.com",
    projectId: "arduinonanoiot",
    storageBucket: "arduinonanoiot.appspot.com",
    messagingSenderId: "1007020323088",
    appId: "1:1007020323088:web:79d7e47e59007bcf497595",
    measurementId: "G-DQBK96Y833"
  };
firebase.initializeApp(config);

function storeImage(imgContent)
{
    // store this at a particular place in our database
    var dbRef = firebase.database().ref('/');
  ///Append image
    dbRef.update({"imageTH":imgContent});
}

// Register a callback for when a detection is updated in the database
var dbRef = firebase.database().ref('/detection/');
dbRef.on("value", newFaceDetected);

function newFaceDetected(snapshot) {
  detection = snapshot.val();
}  
////////
  var alertMessage4 = 0
  var dbRef = firebase.database().ref('/');
  dbRef.on("value", showData);

function showData(snapshot) {
  /* Get the data value into a Javascript object*/
  var sensorReadings = snapshot.val();
  alertMessage4 = sensorReadings.alert4;
  if(alertMessage4==1){
    const audio = new Audio();
    // audio.src = "https://s3-us-west-2.amazonaws.com/s.cdpn.io/28963/song18.mp3";
    // audio.play();
    console.log(audio);
    // var alertSound = new Audio('http://codeskulptor-demos.commondatastorage.googleapis.com/GalaxyInvaders/pause.wav');
    alert("Please come back");
    alertMessage4 =0;
     dbRef.update({"alert3":alertMessage4});
  }
}
