# P4 514 team video input

A Pen created on CodePen.io. Original URL: [https://codepen.io/yiwei68/pen/yLpyORz](https://codepen.io/yiwei68/pen/yLpyORz).

